<?php
include 'config.php';
 
$username = $_POST['username'];
$password = $_POST['pass'];
 
$login = mysql_query("select * from user where user='$username' and pass='$password'");
$cek = mysql_num_rows($login);
 
if($cek > 0){
	session_start();
	$_SESSION['user'] = $username;
	$_SESSION['status'] = "login";
	header("location:index.php");
}else{
	header("location:login.php");	
}
 
?>