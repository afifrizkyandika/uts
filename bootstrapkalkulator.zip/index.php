<!DOCTYPE html>
<html>
<?php 
	include 'config.php';
 
	// mengaktifkan session
	session_start();
	if($_SESSION['status'] !="login"){
	header("location:login.php");
}
?>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=1,initial-scale=1,user-scalable=1" />
	<title>Kalkulator Sederhana dengan PHP &amp; CSS Bootstrap</title>
	<link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
	<link href="http://fonts.googleapis.com/css?family=Lato:100italic,100,300italic,300,400italic,400,700italic,700,900italic,900" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/util.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="assets/vendor/daterangepicker/daterangepicker.css">
	
</head>
<body>
	<?php 
	if(isset($_POST['hitung'])){
		$NilaiA = $_POST['NilaiA'];
		$NilaiB = $_POST['NilaiB'];
		$operasi = $_POST['operasi_perhitungan'];
		switch ($operasi) {
			case 'penjumlahan':
				$hasil = $NilaiA+$NilaiB;
			break;
			case 'pengurangan':
				$hasil = $NilaiA-$NilaiB;
			break;
			case 'perkalian':
				$hasil = $NilaiA*$NilaiB;
			break;
			case 'pembagian':
				$hasil = $NilaiA/$NilaiB;
			break;
			case 'mod':
				$hasil = $NilaiA%$NilaiB;
			break;
			case 'akar':
				$hasil = sqrt($NilaiA);
			break;
		}
	}
	?>
	<section class="container">
			<section class="login-form">
				<form method="post" action="" role="login">
					<img src="assets/images/icons/favicon.ico" class="img-responsive" alt="" />
					<span class="login100-form-title p-b-0">
						Mathematic Equation
					</span>
					<input type="text" name="NilaiA" placeholder="Input Nilai A" required class="form-control input-lg" onkeypress="return validasi_number_gugel88(event)"/>
					<input type="text" name="NilaiB" placeholder="Input Nilai B" required class="form-control input-lg" onkeypress="return validasi_number_gugel88(event)"/>
				    <select class="form-control input-lg" name="operasi_perhitungan">
				      <option>-- Pilih --</option>
				      <option value="penjumlahan">+</option>
				      <option value="pengurangan">-</option>
				      <option value="perkalian">x</option>
				      <option value="pembagian">:</option>
					  <option value="mod">%</option>
					  <option value="akar">Root</option>
				    </select>
					<button type="submit" name="hitung" class="btn btn-lg btn-danger btn-block">Hitung</button>
					
					<?php if(isset($_POST['hitung'])){ ?>
						<input type="text" value="<?php echo $hasil; ?>" class="form-control input-lg">
					<?php }else{ ?>
						<input type="text" placeholder="Hasil" class="form-control input-lg" disabled>
					<?php } ?>
					
					<a class="btn btn-lg btn-primary btn-block" href="logout.php">logOut</a>

				</form>
			</section>
	</section>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<script>
    function validasi_number_gugel88(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
       if (charCode > 31 && (charCode < 48 || charCode > 57))
 
        return false;
      return true;
    }
</script>
</body>
</html>